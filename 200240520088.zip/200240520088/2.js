function valid1()
{
    let u = document.querySelector("#user").value;
    let p = document.querySelector("#pass").value;

  //  let v1 = /^[A-Za-z0-9]{6,20}$/;
   // let v2 = /^[A-Za-z0-9]{6,}$/;

    if (u === "") {
        alert("Please insert UserName!");
    }
    
    
    if (p === "") {
        alert("Please insert Password");
    }

    
    let clone = document.querySelector("#clm").cloneNode(true);
    clone.children[0].innerHTML = u;

    console.log(clone);

    clone.removeAttribute('id');


    let x = document.querySelector('#clm');
    x.insertBefore(clone, clm.firstChild);


    let clone2 = document.querySelector("#clm").cloneNode(true);
    clone2.children[0].innerHTML = p;

    clone2.removeAttribute('id');

    let y = document.querySelector('#clm');

    y.insertBefore(clone2, clm.firstChild);



    document.querySelector("#user").value = "";
    document.querySelector("#pass").value = "";
    

}